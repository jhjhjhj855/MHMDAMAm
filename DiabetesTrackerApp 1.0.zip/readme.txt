
FREE APP

Created by WebIntoApp.com on Thursday 19th of June 2025 04:00:18 PM.

Release APK & App Bundle (AAB) ready to be submitted to Google Play Store 
and to any other APK / AAB store over the internet.

-------------------------------------
App ID:			797920
App Key:		DTQtVbfNUPWaSeibMiWXvQRTyeBkRPTK
App Name:		DiabetesTrackerApp
App Version:	1.0
Package:		com.diabetestrackerapp.diabetestrackerapp
Mode:			Free App
-------------------------------------

Your free app is ready, you can now publish it to the 
google play store and to any apk app store on the internet.

-------------------------------------
Please note, your app is under a FREE mode, you can always 
convert it to your own dedicated and branded mobile app for 
Android and iOS with all the premium features at:

https://demo.webintoapp.com/author/apps/797920/edit?cmd=app-switcher

-------------------------------------
Here are some useful links:
-------------------------------------

You can edit your app at:
https://demo.webintoapp.com/author/apps

Get installs statistics at:
https://demo.webintoapp.com/author/stats?appid=797920

The Author Area:
https://demo.webintoapp.com/author/dashboard

-------------------------------------
WebIntoApp.com Team.
https://www.webintoapp.com
-------------------------------------
